import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Header.css";

const Header = () => {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <header className="navbar">
      <div className="logo">
        <h2>Paws & Play Pet Shop</h2>
      </div>

      {/* Nav Menu */}
      <nav className="nav-menu">
        <Link to="/" className="nav-item">Home</Link>
        <Link to="/about" className="nav-item">About</Link>
        <Link to="/contact" className="nav-item">Contact</Link>

        {/* Dashboard based on role */}
        {user && user.role === "ADMIN" && (
          <Link to="/Admindashboard" className="nav-item">Admin</Link>
        )}

        {user && user.role !== "ADMIN" && (
          <Link to="/userdashboard" className="nav-item">Dashboard</Link>
        )}
      </nav>

      {/* Right Buttons */}
      <div className="nav-right">
        {!user ? (
          <>
            <Link to="/login" className="btn login-btn">Login</Link>
            <Link to="/register" className="btn register-btn">Register</Link>
          </>
        ) : (
          <button className="btn logout-btn" onClick={handleLogout}>
            Logout
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
