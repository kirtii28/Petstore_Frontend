import React from "react";
import '../Component/Footer.css';
import { Link } from "react-router-dom";

const Footer = () => {
    return (
        <>
            <footer id="footer">
                <div id="footer-list">
                    <div>
                        <h2>Support</h2>
                        <ul>
                            <li><Link to="/helpcenter">Pet Care</Link></li>
                            <li><Link to="/helpcenter">Contact Customer Service</Link></li>
                            <li>Safety Resources Center</li>
                        </ul>
                    </div>
                    <div>
                        <h2>Discover</h2>
                        <ul>
                            <li><Link to="/dealspage">Seasonal Cloths</Link></li>
                            <li><Link to="/articlespage">articles</Link></li>
                            {/* <li>Health Care</li> */}
                            <li><Link to="/carrental">Health Care</Link></li>
                        </ul>
                    </div>
                    <div>
                        <h2>About</h2>
                        <ul>
                            <li><Link to="/abouttravel">About Paws & Play Pet Shop.com</Link></li>
                            <li>Package & Delivery</li>
                            <li>Privacy Policy</li>
                            <li>Terms & Conditions</li>
                        </ul>
                    </div>
                </div>
                <div id="paragraph">
                    <p>
                        Paws & Play Pet Shop.com is a part of Pet Care holding Inc., the world leader in online Pets related services.<br />
                        Copyright © 1996–2026 Paws & Play Pet Shop.com. All rights reserved
                    </p>
                </div>
            </footer>
        </>
    );
}

export default Footer;