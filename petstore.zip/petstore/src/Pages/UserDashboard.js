import React, { useEffect, useState } from "react";
import "./UserDashboard.css";
import { Link, useNavigate } from "react-router-dom";

import axios from "axios";
const UserDashboard = () => {
  const navigate = useNavigate();

    const [pets, setPets] = useState([]);

     useEffect(() => {
   
      axios.get("http://localhost:8080/pets/all")
        .then(res => setPets(res.data))
        .catch(err => console.error(err));
    }
  , []);

  
  
  const handleLogout = () => {
    // Removes the saved user data from browser storage.
    localStorage.removeItem("user");
    navigate("/login");
  };

 
  const addToCart = async (petId) => {
        const user = JSON.parse(localStorage.getItem("user"));
        console.log("Userid: ",user.id , "petid: ",petId);
        if (!user) {
          alert("Please login first!");
          navigate("/login");
          return;
        }

        try {
          await axios.post(
            "http://localhost:8080/cart/add",
            null,
            {
              params: {
                userid: user.id,
                petid: petId,
                quantity: 1
              }
            }
          );
          
          alert("Pet added to cart 🐾");
          navigate("/cart");
        } catch (error) {
          console.error(error);
          alert("Failed to add pet to cart");
        }
};


  return (
    <div className="dashboard">

      
      <nav className="usernavbar">
        <div className="userlogo">PetShop</div>

        <ul className="usernav">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/cart">View Cart <i class="fa-solid fa-cart-shopping"></i></Link></li>

          { (
            <>

              <li><Link to="/userprofile">Profile</Link></li>
              <li>
                
                <button className="logout-btn" onClick={handleLogout}>
                  Logout
                </button>
              </li>
            </>
          
          )}
        </ul>
      </nav>
      


      <section className="hero">
        <div className="hero-content">
          <h1>Find your pet</h1>
          <p>
            In our shelter there are several pets who wait only for you.  
            They want a lovely family and a cozy home.  
            Please help them to find a new family who will love them!
          </p>
          <button className="adopt-btn">Let's Adopt</button>
        </div>
        <div className="hero-img"></div>
      </section>

    


      <section className="actions">
        <div className="action-card">
          <span>🐶</span>
          <p>Adopt a pet</p>
        </div>
        <div className="action-card">
          <span>🤝</span>
          <p>Be a volunteer</p>
        </div>
        <div className="action-card">
          <span>❤️</span>
          <p>Donate for them</p>
        </div>
      </section>

      

      <section className="pets-section">
        <h2>Who are waiting for You?</h2>
       <div className="pets-container">
                  

                  <div className="pet-cards">
                    {pets.map((p) => (
                      <div className="pet-card" key={p.id}>
                        
                      
                        {p.image ? (
                          <img
                            src={p.image}
                            alt="pet"
                            className="pet-img" style={{height:"180px"}}
                          />
                        ) : (
                          <div className="no-img">No Image</div>
                        )}

                       
                          <h3>{p.petname}</h3>
                        <p><strong>Breed:</strong> {p.breed}</p>
                        {/* <p><strong>Age:</strong> {p.age} years</p> */}
                        <p><strong>Gender:</strong> {p.gender}</p>
                        <p><strong>Status:</strong> {p.status}</p>
                        <p className="price">₹{p.price}</p>
                       

                       
                        
                        <button className="more-btn"  onClick={() => addToCart(p.id)}>Adopt Me</button>
                        
                       <div className="btn-group">
                          </div>

                      </div>
                    ))}
                  </div>
                </div>


        <button className="more-btn">More</button>
      </section>

      
      
      
      <section className="stats-section">
        <h2>Our Statistic</h2>
        <div className="stats-grid">
          <div className="stat-item">
            <img src="https://i.pinimg.com/736x/36/29/46/362946fbab61092d50aeb022a6afe239.jpg" alt="dog" />
            <h3>57</h3>
            <p>dogs</p>
          </div>

          <div className="stat-item">
            <img src="https://i.pinimg.com/474x/b3/2e/df/b32edfb7da5ef8d5e85740b3100b1b2f.jpg" alt="cat" />
            <h3>29</h3>
            <p>cats</p>
          </div>

          <div className="stat-item">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyx6du9xhguczlXeQLIQ7x-OT1_qlFKOTuug&s" alt="capacity" />
            <h3>77</h3>
            <p>capacity</p>
          </div>

          <div className="stat-item">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfTvJTN8WthuYjEqVpO3GOmc9G1X5xeLring&s" alt="adopted" />
            <h3>231</h3>
            <p>adopted</p>
          </div>
        </div>
      </section>

    </div>
  );
};

export default UserDashboard;
