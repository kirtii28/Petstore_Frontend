import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./userprofile.css";

const Userprofile = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const [form, setForm] = useState({
    name: "",
    email: "",
    contact: "",
  });

  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState("");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    axios
      .get(`http://localhost:8080/user/profile/${user.id}`)
      .then((res) => {
        setForm(res.data);
        if (res.data.profileimg) {
          setPreview(`data:image/jpeg;base64,${res.data.profileimg}`);
          console.log("res.data: ", res.data);
          
        }
      });
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleImage = (e) => {
    setImage(e.target.files[0]);
    setPreview(URL.createObjectURL(e.target.files[0]));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = new FormData();
    data.append(
      "user",
      new Blob([JSON.stringify(form)], { type: "application/json" })
    );
    if (image) data.append("image", image);

    await axios.put(
      `http://localhost:8080/user/profile/${user.id}`,
      data
    );

    alert("Profile updated successfully ✅");
  };

  return (
    <div className="profile-container">
      <h2>My Profile</h2>

      <form onSubmit={handleSubmit} className="profile-card">
        <img
          src={preview || "/default-user.png"}
          alt="profile"
          className="profile-img"
        />

        <input type="file" onChange={handleImage} />

        <input
          type="text"
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Name"
        />

        <input type="email" value={form.email} disabled />

        <input
          type="text"
          name="contact"
          value={form.contact}
          onChange={handleChange}
          placeholder="Contact"
        />

        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default Userprofile;
