import React, { useEffect, useState } from "react";
import "./AdminDashboard.css";
import "./Users.css";
import axios from "axios";

const AdminDashboard = () => {

  const [selected, setSelected] = useState("home");
  const [pets, setPets] = useState([]);
  const [users, setusers] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);


      const [petForm, setPetForm] = useState({
      petname: "",
      breed: "",
      age: "",
      gender: "",
      status: "",
      price: "",
      image: ""
    });

        const handleEditPet = (pet) => {
            setEditId(pet.id);        
            setPetForm({             
              petname: pet.petname,
              breed: pet.breed,
              age: pet.age,
              gender: pet.gender,
              status: pet.status,
              price: pet.price,
              image: pet.image
            });

         setIsEditing(true);       
    };

    const handleUpdatePet = async (e) => {
        e.preventDefault();

        try {
          await axios.put(`http://localhost:8080/pets/update/${editId}`, petForm);

          alert("Pet Updated Successfully!");

        
          setPets(
            pets.map((p) => (p.id === editId ? { ...p, ...petForm } : p))
          );

          setIsEditing(false);   
          setEditId(null);

        } catch (err) {
          console.error(err);
          alert("Error updating pet");
        }
      };



      


            const handleDeletePet = async (id) => {
          if (!window.confirm("Are you sure you want to delete this pet?")) {
            return;
          }

          try {
            await axios.delete(`http://localhost:8080/pets/deleteby/${id}`);

            alert("Pet Deleted Successfully!");

           
            setPets(pets.filter((pet) => pet.id !== id));

          } catch (err) {
            console.error(err);
            alert("Error deleting pet");
          }
        };


 
  useEffect(() => {
    if (selected === "viewpets") {
      axios.get("http://localhost:8080/pets/all")
        .then(res => setPets(res.data))
        .catch(err => console.error(err));
        
        
    }
  }, [selected]);


  useEffect(() => {
    if (selected === "viewusers") {
      axios.get("http://localhost:8080/user/get")
        .then(res => setusers(res.data))
        .catch(err => console.error(err));
       
        
    }
  }, [selected]);

   

    const handlePetChange = (e) => {
  setPetForm({ ...petForm, [e.target.name]: e.target.value });
};

          const handleAddPet = async (e) => {
          e.preventDefault();

          try {
            console.log("Perform: ",petForm);
            
            await axios.post("http://localhost:8080/pets/add", petForm);

            alert("Pet Added Successfully!");

           
            setPetForm({
              petname: "",
              breed: "",
              age: "",
              gender: "",
              status: "",
              price: "",
              image: ""
            });

          
            setSelected("viewpets");

          } catch (err) {
            console.error(err);
            alert("Error adding pet");
          }
        };


      
  
  const renderContent = () => {
    switch (selected) {
      case "viewpets":
           return (
                <div className="pets-container">
                  <h2>📌 All Pets</h2>

                  <div className="pet-cards">
                    {pets.map((p) => (
                      <div className="pet-card" key={p.id}>
                        
                      
                        {p.image ? (
                          <img
                            src={p.image}
                            alt="pet"
                            className="pet-img"
                          />
                        ) : (
                          <div className="no-img">No Image</div>
                        )}

                       
                          <h3>{p.petname}</h3>
                        <p><strong>Breed:</strong> {p.breed}</p>
                        <p><strong>Age:</strong> {p.age} years</p>
                        <p><strong>Gender:</strong> {p.gender}</p>
                        <p><strong>Status:</strong> {p.status}</p>
                        <p className="price">₹{p.price}</p>
                       

                       
                        

                        
                       <div className="btn-group">
                          <button className="view-btn"  onClick={() => handleEditPet(p)}>Edit</button>
                          <button className="delete-btn" onClick={() => handleDeletePet(p.id)}>Delete</button>
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
              );



      case "viewusers":
  return (
          <div className="users-container">
            <h2>📌 All Users</h2>

            <table className="user-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>User Name</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Role</th>
                   {/* <th>Registered Date</th> */}
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {users.map((p) => (
                  <tr key={p.id}>
                    <td>{p.id}</td>
                    <td>{p.name}</td>
                    <td>{p.contact}</td>
                    <td>{p.email}</td>
                   
                    <td>{p.role}</td>
                     {/* <td>{p.addeddate}</td> */}
                    <td>
                      <button className="block-btn">Block</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );



      case "viewcart":
        return <h2>📌 All Cart Items Will Show Here</h2>;

     case "addpet":
            return (
              <div className="addpet-container">
                <h2>➕ Add New Pet</h2>

                <form className="addpet-form" onSubmit={handleAddPet}>
                  
                  <input
                    type="text"
                    name="petname"
                    placeholder="Pet Name"
                    value={petForm.petname}
                    onChange={handlePetChange}
                    required
                  />

                  <input
                    type="text"
                    name="breed"
                    placeholder="Breed"
                    value={petForm.breed}
                    onChange={handlePetChange}
                    required
                  />

                  <input
                    type="number"
                    name="age"
                    placeholder="Age"
                    value={petForm.age}
                    onChange={handlePetChange}
                    required
                  />

                  <input
                    type="text"
                    name="gender"
                    placeholder="Gender (Male/Female)"
                    value={petForm.gender}
                    onChange={handlePetChange}
                    required
                  />

                  <input
                    type="text"
                    name="status"
                    placeholder="Status (Available/Sold)"
                    value={petForm.status}
                    onChange={handlePetChange}
                  />

                  <input
                    type="number"
                    name="price"
                    placeholder="Price"
                    value={petForm.price}
                    onChange={handlePetChange}
                    required
                  />

                  <input
                    type="text"
                    name="image"
                    placeholder="Image URL"
                    value={petForm.image}
                    onChange={handlePetChange}
                  />

                  <button type="submit">Add Pet</button>
                </form>
              </div>
            );


      default:
        return (
          <div className="admin-welcome">
              <h1>Welcome Back, Admin 👩‍💼🐾</h1>
              <p className="admin-subtitle">
                Manage your pet store with love, care, and confidence 💙
              </p>

              <div className="quote-box">
                <p>
                  “Until one has loved an animal, a part of one’s soul remains unawakened.”
                </p>
                <span>— Anatole France</span>
              </div>

              <div className="pet-images">
                <img
                  src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b"
                  alt="Happy Dog"
                />
                <img
                  src="https://images.unsplash.com/photo-1518791841217-8f162f1e1131"
                  alt="Cute Cat"
                />
                <img
                  src="https://i.ytimg.com/vi/Y29TVPloNaY/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAE_cNN2BTTW8l5GTsVMffoavmGZg"
                  alt="Pet Store"
                />
              </div>

              <p className="admin-footer-text">
                🐕 Every pet you manage brings happiness to a home. Keep going!
              </p>
            </div>

        );
    }
  };

  return (
    <div className="admin-container">
    
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <h2 className="admin-logo">PetShop Admin</h2>

        <ul className="admin-menu">
          <li onClick={() => setSelected("viewpets")}>View All Pets</li>
          <li onClick={() => setSelected("viewusers")}>View All Users</li>
          <li onClick={() => setSelected("viewcart")}>View Cart Items</li>
          <li onClick={() => setSelected("addpet")}>Add New Pet</li>
        </ul>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        {renderContent()}
          
      </main>
       {isEditing && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>Edit Pet</h2>

            <form onSubmit={handleUpdatePet} className="edit-form">
              <input type="text" name="petname" value={petForm.petname} onChange={handlePetChange} required />
              <input type="text" name="breed" value={petForm.breed} onChange={handlePetChange} required />
              <input type="number" name="age" value={petForm.age} onChange={handlePetChange} required />
              <input type="text" name="gender" value={petForm.gender} onChange={handlePetChange} required />
              <input type="text" name="status" value={petForm.status} onChange={handlePetChange} />
              <input type="number" name="price" value={petForm.price} onChange={handlePetChange} required />
              <input type="text" name="image" value={petForm.image} onChange={handlePetChange} />

              <button type="submit" className="update-btn">Update</button>
              <button className="close-btn" onClick={() => setIsEditing(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}
      

    </div>
  );
};

export default AdminDashboard;
