import React, { useState } from "react";
import axios from "axios";
import "./ForgotPassword.css";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const navigate = useNavigate();

  const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@#]).{6,}$/;

  const handleReset = async (e) => {
    e.preventDefault();

   
    if (!passwordRegex.test(newPassword)) {
      alert(
        "Password must contain:\n• 1 Capital Letter\n• 1 Number\n• 1 Special character (@ or #)\n• Minimum 6 characters"
      );
      return;
    }

   
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      await axios.put("http://localhost:8080/user/forgot-password", {
        email: email,
        password: newPassword
      });

      alert("Password updated successfully!");
      navigate("/login");
    } catch (error) {
      alert("Email not found!");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>Reset Password 🔐</h2>

        <form onSubmit={handleReset}>
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter registered email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label>New Password</label>
          <input
            type="password"
            placeholder="Eg: Abc@123"
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />

          <label>Confirm Password</label>
          <input
            type="password"
            placeholder="Re-enter new password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />

          <button type="submit">Reset Password</button>
        </form>
      </div>
    </div>
  );
};

export default ForgotPassword;
