import React from "react";
import "./About.css";

const About = () => {
  return (
    <div className="about-container">

      
      <div className="about-hero">
        <h1>About PetShop</h1>
        <p>Your Trusted Partner for All Pet Needs</p>
      </div>

      
      <section className="about-section">
        <h2>Who We Are</h2>
        <p>
          PetShop is an online pet store dedicated to providing high–quality pets,
          pet food, accessories, and health care products. We believe pets are 
          family, and they deserve the very best.
        </p>
        <p>
          Our aim is to create a safe and joyful environment for pets and pet 
          lovers by offering reliable products and services across all categories.
        </p>
      </section>

      
      <section className="mission-section">
        <h2>Our Mission</h2>
        <p>
          To bring happiness to every home by helping people find the right pet 
          and by providing premium-quality pet care essentials at affordable prices.
        </p>
      </section>


      <section className="why-section">
        <h2>Why Choose Us?</h2>
        <div className="why-cards">
          <div className="why-card">
            <img src="https://cdn-icons-png.flaticon.com/512/616/616408.png" alt="Healthy Pets" />
            <h3>Healthy & Well-Cared Pets</h3>
            <p>We provide pets that are healthy, vaccinated, and professionally cared for.</p>
          </div>

          <div className="why-card">
            <img src="https://cdn-icons-png.flaticon.com/512/3524/3524631.png" alt="Delivery" />
            <h3>Fast Delivery</h3>
            <p>We ensure quick delivery of pet essentials right to your doorstep.</p>
          </div>

          <div className="why-card">
            <img src="https://cdn-icons-png.flaticon.com/512/3524/3524753.png" alt="Support" />
            <h3>24/7 Customer Support</h3>
            <p>Our team is always available to help you with any queries.</p>
          </div>
        </div>
      </section>

     
      <section className="team-section">
        <h2>Meet Our Team</h2>
        <div className="team-cards">
          <div className="team-card">
            <img src="https://i.pinimg.com/736x/fc/11/2c/fc112c31d94f03366c7dbc45d710aaa6.jpg" alt="Team Member" />
            <h3>Aditya Gosavi</h3>
            <p>Veterinary Expert</p>
          </div>

          <div className="team-card">
            <img src="https://i.pinimg.com/736x/96/c9/55/96c9558f5cd215152fdc994e66efdd3d.jpg" alt="Team Member" />
            <h3>Srushti Gosavi</h3>
            <p>Pet Care Specialist</p>
          </div>

          <div className="team-card">
            <img src="https://i.pinimg.com/736x/ac/34/d6/ac34d645313cf7e8f1636a61c10c68d6.jpg" alt="Team Member" />
            <h3>Chetan Gosavi</h3>
            <p>Customer Support Lead</p>
          </div>
        </div>
      </section>

    </div>
  );
};

export default About;
