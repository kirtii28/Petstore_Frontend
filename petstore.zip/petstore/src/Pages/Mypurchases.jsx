import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Mypurchases.css";

const Mypurchases = () => {
  const [purchases, setPurchases] = useState([]);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    axios
      .get(`http://localhost:8080/purchasedorder/user/${user.id}`)
      .then((res) => setPurchases(res.data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="purchases-container">
      <h2 className="page-title">My Purchases</h2>

      {purchases.length === 0 ? (
        <div className="empty-purchase">
          <p>You haven’t purchased anything yet 🛒</p>
        </div>
      ) : (
        <>
          <div className="delivery-note">
            🐾 Your pet will reach your home within <b>7 working days</b>
          </div>

          {purchases.map((item) => (
            <div className="purchase-card" key={item.id}>
              <img
                src={item.pet.image}
                alt={item.pet.petname}
                className="pet-image"
              />

              <div className="purchase-details">
                <h3>{item.pet.petname}</h3>
                <p><b>Breed:</b> {item.pet.breed}</p>
                <p><b>Price:</b> ₹{item.price}</p>
                <p><b>Quantity:</b> {item.quantity}</p>
                <p>
                  <b>Purchased On:</b>{" "}
                  {new Date(item.purchasedOn).toLocaleDateString()}
                </p>

                <span className="order-status">Order Confirmed</span>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
};

export default Mypurchases;
