import React, { useState } from "react";
import "./Login.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");


  const navigate = useNavigate();

  const handleLogin = async(e) => {
    e.preventDefault();
   
    
    

     try {
      console.log("New User: ",email , "password: ", password);
      const response = await axios.get( "http://localhost:8080/user/login",{
      params: { 
                email: email, 
                password: password
               }
        }
      );

        localStorage.setItem(
            "user",
            JSON.stringify({
              id: response.data.id,
              name: response.data.name,
              email: response.data
              .email,
              role: response.data.role   // 👈 ADD THIS
            })
          );
      
      alert("Login successful!");

       if (response.data.role === "ADMIN" || response.data.role === "admin") {
            navigate("/Admindashboard");
          } else {
            navigate("/userdashboard");
          }
     
      console.log("Response:", response.data);

    } catch (error) {
      console.error("Error adding user:", error);
      alert("Login failed!");
    }
    
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2 className="login-title">PetShop Login</h2>
        <form onSubmit={handleLogin} className="login-form">
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label>Password</label>
            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <div className="forgot-password">
              <span onClick={() => navigate("/forgot-password")}>
                Forgot Password?
              </span>
            </div>



          <button type="submit">Login</button>
        </form>
        <p className="signup-link">
          Don't have an account? <a href="/register">Sign up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
