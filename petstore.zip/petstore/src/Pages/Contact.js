import React, { useState } from "react";
import "./Contact.css";

const Contact = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent! (You can connect this to backend)");
  };

  return (
    <div className="contact-container">

      
      <div className="contact-hero">
        <h1>Contact Us</h1>
        <p>We are here to help! Get in touch with us any time.</p>
      </div>

      <div className="contact-content">
        
        {/* Contact Form */}
        <div className="contact-form-card">
          <h2>Send Us a Message</h2>

          <form onSubmit={handleSubmit} className="contact-form">
            <input 
              type="text" 
              name="name" 
              placeholder="Your Name" 
              value={form.name}
              onChange={handleChange}
              required 
            />

            <input 
              type="email" 
              name="email" 
              placeholder="Your Email" 
              value={form.email}
              onChange={handleChange}
              required 
            />

            <input 
              type="text" 
              name="phone" 
              placeholder="Your Phone Number" 
              value={form.phone}
              onChange={handleChange}
              required 
            />

            <textarea 
              name="message" 
              placeholder="Your Message" 
              rows="5" 
              value={form.message}
              onChange={handleChange}
              required 
            ></textarea>

            <button type="submit">Send Message</button>
          </form>
        </div>

        {/* Contact Details */}
        <div className="contact-details">
          <h2>Contact Information</h2>

          <p><strong>📍 Address:</strong> PetShop, Main Street, Mumbai, India</p>
          <p><strong>📞 Phone:</strong> +91 9876543210</p>
          <p><strong>📧 Email:</strong> support@petshop.com</p>

          <div className="map-box">
            <iframe
              title="PetShop Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241317.1161001573!2d72.7410083966249!3d19.0825223225038!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c630e6939f5f%3A0xdea3987dadd3617e!2sMumbai!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
              width="100%"
              height="250"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Contact;
