import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Cart.css";

const Cart = () => {
  const navigate = useNavigate();
  const [cartitems, setitems] = useState([]);

  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const proceedToPay = async () => {
  try {
    const res = await axios.get(`http://localhost:8080/getTransaction/${totalAmount}`);

    const options = {
      key: res.data.key,
      amount: res.data.amount,
      currency: res.data.currency,
      name: "Pet Adoption Store",
      description: "Payment for Pet Adoption",
      order_id: res.data.orderId,

      handler: async function (response) {
        alert("Payment Successful! 🎉");
        console.log(response);

        try {
          
          await axios.post("http://localhost:8080/purchasedorder/confirm", null, {
            params: {
              userId: user.id,
              paymentId: response.razorpay_payment_id,
            },
          });

          
          setitems([]);

         
          navigate("/mypurchases");

        } catch (err) {
          console.error("Order confirmation failed", err);
          alert("Payment done but order not saved");
        }
      },

      prefill: {
        name: user ? user.name : "Customer",
        email: user ? user.email : "",
      },

      theme: {
        color: "#cc3373ff",
      },
    };

    const razor = new window.Razorpay(options);
    razor.open();

  } catch (error) {
    console.log("Payment Error:", error);
  }
};


  useEffect(() => {
    if (!user) return;

    axios
      .get(`http://localhost:8080/cart/user/${user.id}`)
      .then((res) => setitems(res.data))
      .catch(console.error);
  }, []);

 
  const increaseQty = async (item) => {
    await axios.patch(`http://localhost:8080/cart/patch/${item.id}`, {
      quantity: item.quantity + 1,
    });

    setitems((prev) =>
      prev.map((i) =>
        i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
      )
    );
  };


  const decreaseQty = async (item) => {
    if (item.quantity <= 1) return;

    await axios.patch(`http://localhost:8080/cart/patch/${item.id}`, {
      quantity: item.quantity - 1,
    });

    setitems((prev) =>
      prev.map((i) =>
        i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i
      )
    );
  };


 const removeItem = async (item) => {
  try {
    await axios.delete("http://localhost:8080/cart/delete", {
      params: {
        userid: user.id,
        petid: item.pet.id
      }
    });

    // update UI
    setitems((prev) =>
      prev.filter((i) => i.pet.id !== item.pet.id)
    );
  } catch (err) {
    console.error("Delete failed:", err);
    alert("Failed to remove item");
  }
};


  //   setitems(cartitems.filter((i) => i.id !== item.id));
  // };


  const totalAmount = cartitems.reduce(
    (sum, item) => sum + item.pet.price * item.quantity,
    0
  );

  return (
    <div>
 
      <nav className="usernavbar">
        <div className="userlogo">PetShop</div>
        <ul className="usernav">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/cart">View Cart</Link></li>
          <li><Link to="/userprofile">🧑🏻‍🦱</Link></li>
          <li>
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </li>
        </ul>
      </nav>

      
      <div className="cart-wrapper">
        <h2>Your Cart</h2>

        {cartitems.length === 0 ? (
          <p className="empty-cart">Your cart is empty 🛒</p>
        ) : (
          <>
            {cartitems.map((item) => (
              <div className="cart-row" key={item.id}>
                <img
                  src={item.pet.image}
                  alt={item.pet.petname}
                  className="cart-img"
                />

                <div className="cart-info">
                  <h3>{item.pet.petname}</h3>
                  <p>Breed: {item.pet.breed}</p>
                  <p>Price: ₹{item.pet.price}</p>
                </div>

                <div className="qty-controls">
                  <button onClick={() => decreaseQty(item)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => increaseQty(item)}>+</button>
                </div>

                <div className="item-total">
                  ₹{item.pet.price * item.quantity}
                </div>

                <button
                  className="remove-btn"
                  onClick={() => removeItem(item)}
                >
                  Remove
                </button>
              </div>
            ))}

          
            <div className="cart-summary">
              <h3>Total Amount: ₹{totalAmount}</h3>
              <button className="checkout-btn"onClick={proceedToPay}>Proceed to Adopt</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Cart;
