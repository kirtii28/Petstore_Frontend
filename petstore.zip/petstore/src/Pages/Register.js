import React, { useState } from "react";
import "./RegisterPage.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [contact, setContact] = useState("");

  const navigate = useNavigate();


  const handleRegister = async (e) => {
    e.preventDefault();


    var newuser = {
      name,
      email,
      password,
      contact
    }
    try {
      console.log("New User: ",newuser);
      
      const response = await axios.post("http://localhost:8080/user/add", newuser);
      
      console.log("Response:", response.data);
       alert("Registration successful!"  );
      navigate("/login"); 

    } catch (error) {
      console.error("Error adding user:", error);
      alert("Registration failed!");
    }
    
   

  };

  return (
    <div className="register-container">
      <div className="register-card">
        <h2 className="register-title">PetShop Registration</h2>
        <form onSubmit={handleRegister} className="register-form">
          <label>Name</label>
          <input
            type="text"
            placeholder="Enter your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />

          <label>Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label>Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <label>Contact Number</label>
          <input
            type="text"
            placeholder="Enter your contact number"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            required
          />

          <button type="submit">Register</button>
        </form>
        <p className="login-link">
          Already have an account? <a href="/login">Login</a>
        </p>
      </div>
    </div>
  );
};

export default Register;
