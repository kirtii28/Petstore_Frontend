import React from 'react';
import './Home.css'; // Import the separate CSS file

const Home = () => {
  return (
    <div className="homepage">
      

      {/* Hero Section */}
      <section className="hero" id="home">
        <div className="hero-content">
          <h2>Welcome to Paws & Play!</h2>
          <p>Your one-stop shop for all your pet's needs. From toys to treats, we've got it all!</p>
          <button className="cta-button">Shop Now</button>
        </div>
        <div className="hero-image">
          <img src="https://www.thesprucepets.com/thmb/VMESw8p8zyafdn-RTo5vBJJ4Iu0=/4000x0/filters:no_upscale():strip_icc()/spruce-pets-cutest-cats-16384c1bdb824b1d87861d62b2a73f4c.jpg" alt="Happy pets" />
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="featured-products" id="products">
        <h2>Featured Products</h2>
        <div className="products-grid">
          <div className="product-card">
            <img src='https://m.media-amazon.com/images/I/71YvB1o9zPL._AC_UF894,1000_QL80_.jpg' alt="Dog " />
            <h3>Dog</h3>
            <p>1235/-</p>
            <button onClick={()=>alert("Please login first!")}>Adopt</button>
          </div>
          <div className="product-card">
            <img src="https://static.vecteezy.com/system/resources/thumbnails/051/778/475/small/an-orange-kitten-sitting-on-a-blanket-photo.jpeg" alt="Cat" />
            <h3>Cat</h3>
            <p>4253/-</p>
            <button onClick={()=>alert("Please login first!")}>Adopt</button>
          </div>
          <div className="product-card">
            <img src="https://images.pexels.com/photos/1661179/pexels-photo-1661179.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="Bird" />
            <h3>Bird</h3>
            <p>914/-</p>
            <button onClick={()=>alert("Please login first!")}>Adopt</button>
          </div>
        </div>
      </section>

      
    </div>
  );
};

export default Home;