import './App.css';
import Header from './Component/Header';
import Footer from './Component/Footer';

import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";

import Home from "./Pages/Home";
import Login from './Pages/Login';
import UserDashboard from './Pages/UserDashboard';
import Register from './Pages/Register';
import AboutUs from './Pages/About';
import Contact from './Pages/Contact';
import Admindashboard from './Pages/Admindashboard';
import Cart from './Pages/Cart';
import ForgotPassword from './Pages/Forgotpassword';
import Mypurchases from './Pages/Mypurchases';
import Userprofile from './Pages/Userprofile';
// import Userprofile from './Pages/Userprofile';

function Layout() {
  const location = useLocation();

  // hide header & footer on these pages
  const hideLayout = ["/userdashboard", "/cart"].includes(location.pathname);

  return (
    <>
      {!hideLayout && <Header />}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/mypurchases" element={<Mypurchases />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/userprofile" element={<Userprofile />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path='/forgot-password' element={<ForgotPassword/>}></Route>
        <Route path="/contact" element={<Contact />} />
        <Route path="/userdashboard" element={<UserDashboard />} />
        <Route path="/Admindashboard" element={<Admindashboard />} />
        <Route path="/cart" element={<Cart />} />

      </Routes>

      {!hideLayout && <Footer />}
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  );
}

export default App;
